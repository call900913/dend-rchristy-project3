Link to the GitHub repo: [https://github.com/call900913/dend-rchristy-project3](https://github.com/call900913/dend-rchristy-project3)

Link to the S3 bucket file: [http://jenkinsbucket6632.s3-website.us-east-2.amazonaws.com](http://jenkinsbucket6632.s3-website.us-east-2.amazonaws.com)
